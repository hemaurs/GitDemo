function Greet() {
  return <h1>Hi</h1>;
}

export { Greet };
