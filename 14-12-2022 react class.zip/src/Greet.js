function Greet() {
  console.log("J");
  return <h1>Heloo</h1>;
}

export { Greet };
