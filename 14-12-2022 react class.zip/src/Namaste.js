function Namaste(props) {
  return (
    <p>
      <h3>Fill form</h3>
      <div
        id="name"
        className="header"
        style={{
          backgroundColor: "red",
          color: "yellow"
        }}
      >
        <label>fname</label> <input type="input" />
      </div>
      <div>
        <label>lname</label> <input type="input" value={props.name} />
      </div>
    </p>
  );
}
export { Namaste };
