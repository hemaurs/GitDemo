import React from "react";
import ReactDOM from "react-dom";
import { Namaste } from "./Namaste";
ReactDOM.render(
  <div>
    <Namaste name="avinash"></Namaste>
    <Namaste name="cp"></Namaste>
  </div>,

  document.getElementById("root")
);
